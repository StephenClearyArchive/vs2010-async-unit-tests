﻿using System;
using System.Text;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ == 3.5)using System.Linq;$endif$$if$ ($targetframeworkversion$ == 4.0)using System.Linq;
$endif$using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Nito.AsyncEx.UnitTests;
using TestClassAttribute = Nito.AsyncEx.UnitTests.AsyncTestClassAttribute;

namespace $rootnamespace$
{
	[TestClass]
	public class $safeitemname$
	{
		[TestMethod]
		public async void TestMethod1()
		{
		}
	}
}
