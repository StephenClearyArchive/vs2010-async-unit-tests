﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Nito.AsyncEx.UnitTests;
using TestClassAttribute = Nito.AsyncEx.UnitTests.AsyncTestClassAttribute;

namespace $rootnamespace$
{
	[TestClass]
	public class $safeitemname$
	{
		[TestMethod]
		public async void TestMethod1()
		{
		}
	}
}
